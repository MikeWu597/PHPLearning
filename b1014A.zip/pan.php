<?php

$canshu=$_SERVER["QUERY_STRING"];

if($canshu=="")

{

die("文件不存在");

}

else

{

$wangzhi="http://pan.baidu.com/share/link?".$canshu;

$file=file_get_contents($wangzhi);

$pattern='/a><a class="dbtn cancel singledbtn" href=(.*?)id="downFileButtom">/i';

preg_match_all($pattern,$file,$result);

$tempurl=implode("",$result[1]);

$fileurlt=str_replace("\"","",$tempurl);

$fileurl=str_replace("&","&",$fileurlt);

header("location:$fileurl");
echo $tempurl;
}

?>