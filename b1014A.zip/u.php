<head>
	<style>
		.div3{ background:#87CEFA;float:left;width:450px}
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body background="/bg.jpg" id="div2">
	<?php include "/header.php"; ?>
	<p></p>
	<div width="900px" align="center" style="color:#87CEFA">
		<h3>Welcome!</h3>
	</div>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Bilibili APIs</h3>
				<p><a href="p/bilibiliapis.php">View</a></p>
			</div>
			<div align="center" class="div3">
				<h3>Control Pages</h3>
				<p><a href="p/controlpages.php">View</a></p>
			</div>
		</div>
	</div>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>S**tease APIs</h3>
				<p><a href="p/steaseapis.php">View</a></p>
			</div>
			<div align="center" class="div3">
				<h3>Online Chat</h3>
				<p><a href="oc/ochatpage.php">View</a></p>
			</div>
		</div>
	</div>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Tenc**t APIs</h3>
				<p><a href="p/qqapis.php">View</a></p>
			</div>
			<div align="center" class="div3">
				<h3>Mojang APIs</h3>
				<p><a href="p/mojangnbnbnb.php">View</a></p>
			</div>
		</div>
	</div>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Network Tools</h3>
				<p><a href="p/networkapis.php">View</a></p>
			</div>
			<div align="center" class="div3">
				<h3>Glype Proxy</h3>
				<p><a href="pr/index.php">View</a></p>
			</div>
		</div>
	</div><div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Storage</h3>
				<p><a href="files/index.php">View</a></p>
			</div>
			<div align="center" class="div3">
				<img src="http://tietu.zuimc.com/server.php?hostname=MCBWA1&host=s4.natfrp.org&port=59796&line=3">
			</div>
		</div>
	</div>
	
	<?php 
		//echo "Hello world!" 
	?>
</body>