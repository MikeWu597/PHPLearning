<head>
	<style>
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body background="../bg.jpg" id="div2">
	<?php include "../header.php"; ?>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Get QQ icon</h3>
			</div>
			
			<form action="process/q_gqi.php" method="post">
				QQ:<input type="text" name="qq">
				<input type="submit">
			</form>
		</div>
	</div>
</body>