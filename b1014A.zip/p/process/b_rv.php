<head>
	<style>
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body background="../../bg.jpg" id="div2">
	<?php include "../../header.php";
	header("Content-type:text/html; charset=utf-8");
	?>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Resolve video</h3>
			</div>
			
			<?php 
				$aid=$_POST["av"];
				$pid=$_POST["p"];
				$url="https://api.kaaass.net/biliapi/video/resolve?id=".$aid."&page=".$pid;
				$data=file_get_contents($url);
				$dec=json_decode($data);
				$pd=$dec->url;
				echo "<h4>Video URL:</h4>".$pd[0]->url;
				echo "<p><a href=\"".$pd[0]->url."\">Download</a></p>";
				$urlfinal=$pd[0]->url;
				echo "<h4>Video Poster:</h4>".$dec->poster;
				echo "<p></p><img url=\"".$dec->poster."\"></img>";
				echo "<p><a href=\"".$dec->poster."\">Download</a></p>";
				echo "<h4>Outpost page</h4>https://www.bilibili.com/blackboard/html5mobileplayer.html?aid=".$aid."&page=".$pid;
				
				//echo "<video controls><source src=\"".$urlfinal."\" type=\"video/flv\"></video>";
				/*echo "<script type=\"text/javascript\" src=\"http://47.94.208.171:233/ckplayer/ckplayer.js\"></script>
					<div id=\"video\" style=\"width:600px;height:400px;\"></div>
					<script type=\"text/javascript\">
						var videoObject = {
							container: '#video',//“#”代表容器的ID，“.”或“”代表容器的class
							variable: 'player',//该属性必需设置，值等于下面的new chplayer()的对象
							flashplayer:false,//如果强制使用flashplayer则设置成true
							video:".$urlfinal."//视频地址
						};
						var player=new ckplayer(videoObject);
					</script>"*/
				//echo "<embed src=\"http://47.94.208.171:233/ckplayer/ckplayer.swf" flashvars=\"video=".$urlfinal."\"  quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" allowFullscreen=\"true\" type=\"application/x-shockwave-flash\"></embed>";
			?>
		</div>
	</div>
</body>