<head>
	<style>
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body background="../../bg.jpg" id="div2">
	<?php include "../../header.php";
	header("Content-type:text/html; charset=utf-8");
	?>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Search Artist</h3>
			</div>
			
			<?php 
				$kw=$_POST["kw"];
				$content=file_get_contents("https://v1.itooi.cn/netease/search?keyword=".$kw."&type=singer&pageSize=1&page=0");
				$contentd=json_decode($content);
				$contentdd=$contentd->data->artists;
				$uname=$contentdd[0]->name;
				$uid=$contentdd[0]->id;
				$upic=$contentdd[0]->picUrl;
				
				$ainfo=file_get_contents("https://v1.itooi.cn/netease/artist/info?id=".$uid);
				$jinfo=json_decode($ainfo);
				$binfo=$jinfo->data->briefDesc;
				
				
				echo "<img src=\"".$upic."\" width=\"50\" height=\"50\"></img>".$uname."<p></p>";
				echo $binfo;
			?>
		</div>
	</div>
</body>