<head>
	<style>
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body background="../../bg.jpg" id="div2">
	<?php include "../../header.php";
	header("Content-type:text/html; charset=utf-8");
	?>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Search music</h3>
			</div>
			
			<?php 
				$kw=$_POST["kw"];
				$res=file_get_contents("https://v1.itooi.cn/netease/search?keyword=".$kw."&type=song&pageSize=1");
				$fol=json_decode($res);
				$sid=$fol->data->songs;
				$sid=$sid[0]->id;
				
				
				$info=file_get_contents("https://v1.itooi.cn/netease/song?id=".$sid);
				$info=json_decode($info);
				$name=$info->data->songs;
				$name=$name[0]->name;
				
				$pic="https://v1.itooi.cn/netease/pic?id=".$sid;
				echo "<img src=\"".$pic."\" width=\"50\" height=\"50\"></img>";
				echo $name."<p></p>";
				
				$sur="https://v1.itooi.cn/netease/lrc?id=".$sid;
				
				$lrc=file_get_contents($sur);
				$c=0;
				echo "<center>";
				echo str_replace("[","<br>[",$lrc,$c);
				echo "<br><br><h4>Total ".$c." sentences.</h4></center>";
			?>
		</div>
	</div>
</body>