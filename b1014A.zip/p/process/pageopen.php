<head>
	<style>
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body background="../../bg.jpg" id="div2">
	<?php include "../../header.php";
	header("Content-type:text/html; charset=utf-8");
	?>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Page Open Test</h3>
			</div>
			
			<?php 
				
				$n=$_POST["kw"];
				function httpcode($url){
					$ch = curl_init();
					$timeout = 3;
					curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
					curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
					curl_setopt($ch, CURLOPT_HEADER, 1);
					curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
					curl_setopt($ch,CURLOPT_URL,$url);
					curl_exec($ch);
					return $httpcode = curl_getinfo($ch,CURLINFO_HTTP_CODE);
					curl_close($ch);		
				}
				echo "Status Code:".httpcode($n)."<br><br>";
				include "sce.php";
				
			?>
			
		</div>
	</div>
</body>