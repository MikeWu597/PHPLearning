<head>
	<style>
		.div3{ background:#87CEFA;float:left;width:900px}
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body background="../bg.jpg" id="div2">
	<?php include "../header.php"; ?>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Network Tools</h3>
			</div>
		</div>
	</div>
	
	<p>
		<div>
			<div width="900px" align="center" style="background:#F7EED6;float:center">
				<div align="center" class="div3">
					<a href="ping.php">Ping IP</a>
					<p></p>
					<a href="iploc.php">IP Location</a>
					<p></p>
					<a href="phone.php">Phone Number Location</a>
					<p></p>
					<a href="pageopen.php">Page Open Test</a>
					<p></p>
					<a href="dotoip.php">Domain to IP</a>
					<p></p>
					<a href="ip.php">My IP</a>
					<p></p>
				</div>
			</div>
		</div>
	</p>
</body>