<head>
	<style>
		.div3{ background:#87CEFA;float:left;width:900px}
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body background="../bg.jpg" id="div2">
	<?php include "../header.php"; ?>
	<p></p>
	<div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<h3>Control Pages</h3>
			</div>
		</div>
		<div width="900px" align="center" style="background:#F7EED6">
			<div align="center" class="div3">
				<?php 
					echo "<h4>.Connections.</h4><br>";
					echo "Your IP address is ".$_SERVER["REMOTE_ADDR"].".<br>";
					echo "You are viewing at port ".$_SERVER["REMOTE_PORT"].".<br>";
					echo "Server signature is ".$_SERVER["SERVER_SIGNATURE"].".<br>";
					echo "<h4>.Scripts.</h4><br>";
					echo "PHP cgi version is ".$_SERVER["GATEWAY_INTERFACE"].".<br>";
					echo "You are running script at server ".$_SERVER["SCRIPT_FILENAME"].".<br>";
					echo "Date now is ".date("F j Y").".<br>";
				?>
			</div>
		</div>
	</div>
</body>