<!DOCTYPE html>
<html>
	<head>
		<style>
			.div3{ background:#87CEFA;float:left;width:450px}
			#div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
			#div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
		</style>
		<meta charset="utf-8" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>文件管理</title>
	</head>
	<body background="../bg.jpg" id="div2">
		<?php include "../header.php"; ?>
		<!------------------------------------文件上传-------------------------------------------------------->
		<center>
			<hr width="30%" align="center">
			<h2>文件上传</h2>
			
		
			<form action="upload_file.php" method="post" enctype="multipart/form-data">
				请选择您要上传的文件：<input type="file" name="myFile" /><br/>
					<input type="submit" value="上传"/>
			</form>
			<br>
		<!------------------------------------文件下载-------------------------------------------------------->
			<hr width="30%" align="center">
			<h2>文件下载</h2>
			
		
			<form action="download_file.php" method="get">
			
				<input  name="filename" type="text" style="width: 17%;" value="" placeholder="请输入文件名，英文不区分大小写" />
			
				<input type="submit" value="点击搜索" />
			
			</form>
			<hr width="30%" align="center">
			<h2>文件列表</h2>
			<?php 
			$dir = scandir("C:\Users\Administrator\Desktop\Apache\UPUPW_AP5.4-1510\UPUPW_AP5.4\htdocs\files\upload");             //使用 scandir()函数取得所有文件及目录
			foreach ($dir as $value){          //使用 foreach 循环
				echo $value."<br>";            //循环输出文件及目录名称
			} 
			?>
		</center>
		
	</body>
</html>