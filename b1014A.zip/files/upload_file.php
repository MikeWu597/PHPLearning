<?php
 
	header("Content_type:text/html;charset=utf8");
	
	//session_start();
	
	$imgname = $_FILES['myFile']['name'];
    $tmp = $_FILES['myFile']['tmp_name'];
	$error=$_FILES['myFile']['error'];
		
   move_uploaded_file($tmp,'upload/'.iconv("UTF-8", "gbk",$imgname));
 
   if ($error==0) {
  			echo "上传成功！";
   }else{
		  switch ($error){
		    case 1:
		      echo "超过了上传文件的最大值，请上传500M以下文件";
		      break;
		    case 2:
		      echo "上传文件过多，请一次上传20个及以下文件！";
		      break;
		    case 3:
		      echo "文件并未完全上传，请再次尝试！";
		      break;
		    case 4:
		      echo "未选择上传文件！";
		      break;
		    case 5:
		      echo "上传文件为0";
	      	 break;
	}
}
 
?>