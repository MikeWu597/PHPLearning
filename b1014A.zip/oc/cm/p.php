<head>
	<style>
		.div3{ background:#87CEFA;float:left;width:450px}
        #div1 { margin:0px auto; width:500px; height:370px ; text-align:center; background:url('bg.jpg');}
        #div2 {  height:330px; filter:alpha(Opacity=50);-moz-opacity:0.5;opacity: 0.5;z-index:100; background-color:#ffffff;  }
    </style>
</head>

<body>
	<?php
		//Process data
		$uname=$_POST["n"];
		$prefix="";
		$suffix="";
		if($_POST["notice"])
		{
			$prefix=$prefix."<h4>";
			$suffix="</h4>".$suffix;
		}
		if($uname!="" && $_POST["ct"]!="")
		{
			$ct=$uname.":".$prefix.$_POST["ct"].$suffix."<br>";
			
			$file=fopen("contents.php","r") or exit("Unable to open file!");
			while (!feof($file))
			{
				$ct=$ct.fgetc($file);
			}
			fclose($file);
			$rit=file_put_contents("contents.php",$ct);
		}
	?>
	<iframe src="contents.php" width="870px" height="250px" name="msgw"></iframe>
	
	<form action="p.php" method="post">
		<?php
			if($uname!="")
			{
				echo "<input type=\"text\" name=\"n\" size=\"20\" value=\"".$uname."\" readonly unselectable=\"on\" >";
			}
			else echo "<input type=\"text\" name=\"n\" size=\"20\">";
			
		?>
		<input type="text" name="ct" size="95">
		<input type="checkbox" name="notice" size="20">Notice
		<input type="submit">
	</form>
</body>